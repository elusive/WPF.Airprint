# Dockerized CUPS
  * supports ldap-authentification
  * various drivers etc..
