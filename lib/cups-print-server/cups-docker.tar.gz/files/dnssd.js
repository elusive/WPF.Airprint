const dnssd = require('/usr/local/lib/node_modules/dnssd');

const browser = dnssd.Browser(dnssd.tcp('http'))
    .on('serviceUp', svc => console.log("Device found: ", svc))
    .on('serviceDown', svc => console.log("Device lost: ", svc))
    .start();
